from yandex_tracker_client import TrackerClient

client = TrackerClient(token="", org_id="97342af268a64520889612d95ad90e4b")
