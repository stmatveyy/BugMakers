# do not edit this exception
class TeamHackathonException(Exception):
    pass

